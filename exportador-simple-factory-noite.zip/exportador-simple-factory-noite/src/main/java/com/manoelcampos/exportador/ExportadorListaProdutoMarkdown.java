package com.manoelcampos.exportador;

public class ExportadorListaProdutoMarkdown extends AbstractExportadorListaProduto {
    @Override
    public String abrirTabela() {
        return null;
    }

    @Override
    public String fecharTabela() {
        return null;
    }

    @Override
    public String abrirLinha() {
        return null;
    }

    @Override
    public String fecharLinha() {
        return null;
    }

    @Override
    public String abrirLinhaTitulos() {
        return null;
    }

    @Override
    public String fecharLinhaTitulos() {
        return null;
    }

    @Override
    public String abrirColuna(String valor) {
        return null;
    }

    @Override
    public String fecharColuna() {
        return null;
    }
}
