import com.manoelcampos.retornoboleto.LeituraRetorno;
import com.manoelcampos.retornoboleto.LeituraRetornoBancoBrasil;
import com.manoelcampos.retornoboleto.ProcessarBoletos;

import java.net.URI;
import java.net.URISyntaxException;

/**
 * Classe para ver o funcionamento da leitura de boletos.
 *
 * @author Manoel Campos da Silva Filho
 */
public class Principal {
    public static void main(String[] args) throws URISyntaxException {
        var processador = new LeituraRetornoBancoBrasil();
        var caminho = "file:///Users/manoelcampos/Documents/IFTO/aulas/padroes/retorno-boleto-noite/banco-brasil-1.csv";
        processador.processar(new URI(caminho));

        //processador.setLeituraRetorno(new LeituraRetornoBancoBradesco());
    }
}
